// Optional: Add interactivity as needed
// Example: highlight navbar on scroll

window.addEventListener('scroll', () => {
  const nav = document.querySelector('nav');
  if (window.scrollY > 10) {
    nav.style.boxShadow = '0 2px 12px rgba(25,55,105, 0.13)';
  } else {
    nav.style.boxShadow = 'none';
  }
});